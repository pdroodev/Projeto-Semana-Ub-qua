const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDarkMode } from '@/lib/useDarkMode';

export default function Header() {
  const { isDark, toggle } = useDarkMode();

  return (
    <header className="bg-card shadow-sm border-b border-border sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-5 flex items-center gap-3">
        <img
          src="https://media.db.com/images/public/69eaa825f9583e5ade6b0471/4fd884de2_T_Pago_logo-removebg-preview1.png"
          alt="Tá Pago? logo"
          className="h-10 w-10 object-contain mix-blend-multiply dark:mix-blend-screen"
        />
        <div className="flex-1">
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-foreground">
            Tá Pago?
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground font-medium">
            Organize suas contas sem complicação
          </p>
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={toggle}
          className="rounded-full h-9 w-9 shrink-0"
          title={isDark ? 'Modo claro' : 'Modo escuro'}
        >
          {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>
      </div>
    </header>
  );
}