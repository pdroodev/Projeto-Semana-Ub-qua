import React, { useState, useMemo } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Receipt, ChevronDown, ChevronRight } from 'lucide-react';
import BillCard from './BillCard';
import { getBillStatus } from '@/lib/useBills';
import ExportButton from './ExportButton';

const statusFilters = [
  { key: 'all', label: 'Todas' },
  { key: 'pending', label: 'Pendentes' },
  { key: 'paid', label: 'Pagas' },
];

function getMonthKey(dueDate) {
  return dueDate.slice(0, 7); // "YYYY-MM"
}

function formatMonthLabel(key) {
  const [year, month] = key.split('-');
  return new Date(Number(year), Number(month) - 1).toLocaleDateString('pt-BR', {
    month: 'long', year: 'numeric',
  });
}

function MonthGroup({ label, bills, onTogglePaid, onDelete }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="mb-4">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 w-full text-left mb-2 group"
      >
        {open
          ? <ChevronDown className="h-4 w-4 text-muted-foreground" />
          : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
        <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground group-hover:text-foreground transition-colors capitalize">
          {label}
        </span>
        <span className="ml-auto text-xs text-muted-foreground">{bills.length} conta{bills.length !== 1 ? 's' : ''}</span>
      </button>
      <AnimatePresence mode="popLayout">
        {open && (
          <div className="grid gap-3">
            {bills.map(bill => (
              <BillCard key={bill.id} bill={bill} onTogglePaid={onTogglePaid} onDelete={onDelete} />
            ))}
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function BillList({ bills, onTogglePaid, onDelete }) {
  const [activeFilter, setActiveFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [groupByMonth, setGroupByMonth] = useState(false);

  const statusOrder = { overdue: 0, warning: 1, pending: 2, paid: 3 };

  const filteredBills = bills
    .filter((bill) => {
      if (activeFilter === 'paid') return bill.paid;
      if (activeFilter === 'pending') return !bill.paid;
      return true;
    })
    .filter((bill) => {
      if (categoryFilter === 'all') return true;
      return bill.category === categoryFilter;
    })
    .sort((a, b) => {
      const byStatus = statusOrder[getBillStatus(a)] - statusOrder[getBillStatus(b)];
      if (byStatus !== 0) return byStatus;
      return a.dueDate.localeCompare(b.dueDate);
    });

  const grouped = useMemo(() => {
    const map = {};
    filteredBills.forEach(bill => {
      const key = getMonthKey(bill.dueDate);
      if (!map[key]) map[key] = [];
      map[key].push(bill);
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [filteredBills]);

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3 shrink-0">
          <h2 className="text-base font-bold text-foreground whitespace-nowrap">Minhas Contas</h2>
          <ExportButton bills={bills} />
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          {/* Group by month toggle */}
          <button
            onClick={() => setGroupByMonth(g => !g)}
            className={`text-xs font-semibold px-3 py-1.5 rounded-full border transition-all ${
              groupByMonth
                ? 'bg-primary text-primary-foreground border-primary'
                : 'border-border text-muted-foreground hover:text-foreground'
            }`}
          >
            Por mês
          </button>
          {/* Status filter */}
          <div className="flex gap-1 bg-muted rounded-full p-1">
            {statusFilters.map((f) => (
              <button
                key={f.key}
                onClick={() => setActiveFilter(f.key)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-full transition-all ${
                  activeFilter === f.key
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
          {/* Category filter */}
          <div className="flex gap-1 bg-muted rounded-full p-1">
            {[
              { key: 'all', label: 'Todas' },
              { key: 'fixa', label: '📌 Fixa' },
              { key: 'variável', label: '📊 Variável' },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setCategoryFilter(f.key)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-full transition-all ${
                  categoryFilter === f.key
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Empty state */}
      {filteredBills.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="h-14 w-14 rounded-2xl bg-muted flex items-center justify-center mb-3">
            <Receipt className="h-6 w-6 text-muted-foreground" />
          </div>
          <p className="text-sm font-medium text-muted-foreground">
            {activeFilter === 'all' ? 'Nenhuma conta cadastrada ainda' : activeFilter === 'paid' ? 'Nenhuma conta paga' : 'Nenhuma conta pendente'}
          </p>
          <p className="text-xs text-muted-foreground mt-1">Adicione uma conta no formulário ao lado</p>
        </div>
      ) : groupByMonth ? (
        grouped.map(([key, monthBills]) => (
          <MonthGroup
            key={key}
            label={formatMonthLabel(key)}
            bills={monthBills}
            onTogglePaid={onTogglePaid}
            onDelete={onDelete}
          />
        ))
      ) : (
        <div className="grid gap-3">
          <AnimatePresence mode="popLayout">
            {filteredBills.map(bill => (
              <BillCard key={bill.id} bill={bill} onTogglePaid={onTogglePaid} onDelete={onDelete} />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}