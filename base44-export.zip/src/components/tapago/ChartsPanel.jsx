import React from 'react';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend,
} from 'recharts';
import { getBillStatus } from '@/lib/useBills';

const GREEN = '#16a34a';
const RED = '#ef4444';
const AMBER = '#f59e0b';
const MUTED = '#94a3b8';

function formatCurrency(val) {
  return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function DonutChart({ bills }) {
  const paid = bills.filter(b => b.paid).reduce((s, b) => s + b.amount, 0);
  const pending = bills.filter(b => !b.paid).reduce((s, b) => s + b.amount, 0);

  const data = [
    { name: 'Pago', value: paid },
    { name: 'Pendente', value: pending },
  ].filter(d => d.value > 0);

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
        Sem dados para exibir
      </div>
    );
  }

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-md text-xs">
          <p className="font-semibold">{payload[0].name}</p>
          <p>{formatCurrency(payload[0].value)}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <ResponsiveContainer width="100%" height={180}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={50}
          outerRadius={75}
          paddingAngle={3}
          dataKey="value"
        >
          <Cell fill={GREEN} />
          <Cell fill={RED} />
        </Pie>
        <Tooltip content={<CustomTooltip />} />
        <Legend
          iconType="circle"
          iconSize={8}
          formatter={(value) => (
            <span className="text-xs text-foreground">{value}</span>
          )}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}

function MonthlyBarChart({ bills }) {
  // Group bills by month (YYYY-MM)
  const monthMap = {};
  bills.forEach(bill => {
    const month = bill.dueDate.slice(0, 7); // "2026-04"
    if (!monthMap[month]) monthMap[month] = { Pago: 0, Pendente: 0 };
    if (bill.paid) monthMap[month].Pago += bill.amount;
    else monthMap[month].Pendente += bill.amount;
  });

  const data = Object.entries(monthMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-6) // last 6 months
    .map(([month, vals]) => {
      const [year, m] = month.split('-');
      const label = new Date(Number(year), Number(m) - 1).toLocaleDateString('pt-BR', {
        month: 'short', year: '2-digit',
      });
      return { month: label, ...vals };
    });

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
        Sem dados para exibir
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-md text-xs space-y-1">
          <p className="font-semibold mb-1">{label}</p>
          {payload.map(p => (
            <p key={p.name} style={{ color: p.fill }}>
              {p.name}: {formatCurrency(p.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={data} barSize={16} barGap={4}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis
          dataKey="month"
          tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tickFormatter={v => `R$${v}`}
          tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
          axisLine={false}
          tickLine={false}
          width={48}
        />
        <Tooltip content={<CustomTooltip />} />
        <Legend
          iconType="circle"
          iconSize={8}
          formatter={(value) => (
            <span className="text-xs text-foreground">{value}</span>
          )}
        />
        <Bar dataKey="Pago" fill={GREEN} radius={[4, 4, 0, 0]} />
        <Bar dataKey="Pendente" fill={RED} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export default function ChartsPanel({ bills }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {/* Donut */}
      <div className="bg-card rounded-xl border border-border shadow-sm p-4">
        <h3 className="text-sm font-bold text-foreground mb-3">Pago vs Pendente</h3>
        <DonutChart bills={bills} />
      </div>

      {/* Bar */}
      <div className="bg-card rounded-xl border border-border shadow-sm p-4">
        <h3 className="text-sm font-bold text-foreground mb-3">Comparativo Mensal</h3>
        <MonthlyBarChart bills={bills} />
      </div>
    </div>
  );
}