import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { getBillStatus } from '@/lib/useBills';

const statusLabels = {
  paid: 'Pago',
  overdue: 'Atrasado',
  warning: 'Vence em breve',
  pending: 'Pendente',
};

export default function ExportButton({ bills }) {
  const handleExport = () => {
    const headers = ['Nome', 'Valor (R$)', 'Vencimento', 'Status'];

    const rows = bills.map((bill) => {
      const status = statusLabels[getBillStatus(bill)];
      const due = new Date(bill.dueDate + 'T00:00:00').toLocaleDateString('pt-BR');
      const amount = bill.amount.toFixed(2).replace('.', ',');
      return [
        `"${bill.name.replace(/"/g, '""')}"`,
        amount,
        due,
        status,
      ].join(';');
    });