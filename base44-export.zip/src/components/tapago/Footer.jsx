import React from 'react';

export default function Footer() {
  return (
    <footer className="py-6 text-center border-t border-border mt-8">
      <p className="text-xs text-muted-foreground font-medium">
        Tá Pago? • Projeto acadêmico • Hackathon 2026
      </p>
    </footer>
  );
}