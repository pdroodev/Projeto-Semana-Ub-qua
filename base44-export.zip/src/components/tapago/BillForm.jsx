import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus } from 'lucide-react';

export default function BillForm({ onAdd }) {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [category, setCategory] = useState('fixa');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim() || !amount || !dueDate) return;
    onAdd({
      name: name.trim(),
      amount: parseFloat(amount),
      dueDate,
      category,
    });
    setName('');
    setAmount('');
    setDueDate('');
    setCategory('fixa');
  };

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-5">
      <h2 className="text-base font-bold text-foreground mb-4">Nova Conta</h2>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <Label htmlFor="bill-name" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Nome da conta
          </Label>
          <Input
            id="bill-name"
            placeholder="Ex: Conta de luz"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="bill-amount" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Valor (R$)
          </Label>
          <Input
            id="bill-amount"
            type="number"
            step="0.01"
            min="0"
            placeholder="0,00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="bill-due" className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Data de vencimento
          </Label>
          <Input
            id="bill-due"
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="mt-1"
          />
        </div>
        <div>
          <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Categoria
          </Label>
          <div className="flex gap-2 mt-1">
            {['fixa', 'variável'].map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`flex-1 py-2 rounded-lg text-sm font-semibold border transition-all capitalize ${
                  category === cat
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-background border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                {cat === 'fixa' ? '📌 Fixa' : '📊 Variável'}
              </button>
            ))}
          </div>
        </div>
        <Button type="submit" className="w-full mt-2 font-semibold" size="lg">
          <Plus className="h-4 w-4 mr-2" />
          Adicionar Conta
        </Button>
      </form>
    </div>
  );
}