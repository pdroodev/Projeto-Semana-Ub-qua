import React from 'react';
import { Button } from '@/components/ui/button';
import { Check, Undo2, Trash2, Calendar } from 'lucide-react';
import { getBillStatus } from '@/lib/useBills';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';

const statusConfig = {
  paid: {
    border: 'border-l-emerald-500',
    badge: 'bg-emerald-100 text-emerald-700',
    label: 'Pago',
  },
  overdue: {
    border: 'border-l-red-500',
    badge: 'bg-red-100 text-red-700',
    label: 'Atrasado',
  },
  warning: {
    border: 'border-l-amber-500',
    badge: 'bg-amber-100 text-amber-700',
    label: 'Vence em breve',
  },
  pending: {
    border: 'border-l-slate-300',
    badge: 'bg-slate-100 text-slate-600',
    label: 'Pendente',
  },
};

export default function BillCard({ bill, onTogglePaid, onDelete }) {
  const status = getBillStatus(bill);
  const config = statusConfig[status];

  const formattedDate = format(new Date(bill.dueDate + 'T00:00:00'), "dd 'de' MMM, yyyy", {
    locale: ptBR,
  });

  const formattedAmount = bill.amount.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.2 }}
      className={`bg-card rounded-xl border border-border shadow-sm overflow-hidden border-l-4 ${config.border}`}
    >
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <h3 className={`font-semibold text-sm truncate ${bill.paid ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
              {bill.name}
            </h3>
            <p className={`text-lg font-bold mt-0.5 ${bill.paid ? 'text-muted-foreground' : 'text-foreground'}`}>
              {formattedAmount}
            </p>
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <Calendar className="h-3 w-3 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">{formattedDate}</span>
              {bill.category && (
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                  bill.category === 'fixa'
                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300'
                    : 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300'
                }`}>
                  {bill.category === 'fixa' ? '📌 Fixa' : '📊 Variável'}
                </span>
              )}
            </div>
          </div>
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full whitespace-nowrap ${config.badge}`}>
            {config.label}
          </span>
        </div>

        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
          <Button
            size="sm"
            variant={bill.paid ? 'outline' : 'default'}
            className="flex-1 text-xs font-semibold h-8"
            onClick={() => onTogglePaid(bill.id)}
          >
            {bill.paid ? (
              <>
                <Undo2 className="h-3 w-3 mr-1.5" />
                Desfazer
              </>
            ) : (
              <>
                <Check className="h-3 w-3 mr-1.5" />
                Marcar como pago
              </>
            )}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
            onClick={() => onDelete(bill.id)}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}