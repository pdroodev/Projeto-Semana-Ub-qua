import React, { useEffect, useState } from 'react';
import { AlertTriangle, X, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

function getDaysUntilDue(dueDate) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate + 'T00:00:00');
  return Math.ceil((due - today) / (1000 * 60 * 60 * 24));
}

export default function UrgentAlert({ bills }) {
  const [open, setOpen] = useState(false);

  const urgentBills = bills.filter(b => {
    if (b.paid) return false;
    const days = getDaysUntilDue(b.dueDate);
    return days === 0 || days === 1;
  });

  useEffect(() => {
    if (urgentBills.length > 0) setOpen(true);
  }, []); // only on mount

  if (urgentBills.length === 0) return null;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed z-50 inset-x-4 top-1/2 -translate-y-1/2 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-full sm:max-w-md"
          >
            <div className="bg-card rounded-2xl shadow-2xl border border-border overflow-hidden">
              {/* Header */}
              <div className="bg-amber-500 px-5 py-4 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                  <AlertTriangle className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h2 className="text-white font-bold text-sm">Atenção! Contas urgentes</h2>
                  <p className="text-amber-100 text-xs">
                    {urgentBills.length} conta{urgentBills.length > 1 ? 's' : ''} vence{urgentBills.length === 1 ? '' : 'm'} hoje ou amanhã
                  </p>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Bill list */}
              <div className="p-4 space-y-2 max-h-72 overflow-y-auto">
                {urgentBills.map(bill => {
                  const days = getDaysUntilDue(bill.dueDate);
                  const isToday = days === 0;
                  return (
                    <div
                      key={bill.id}
                      className={`flex items-center gap-3 rounded-xl px-4 py-3 border ${
                        isToday
                          ? 'bg-red-50 border-red-200 dark:bg-red-950/30 dark:border-red-800'
                          : 'bg-amber-50 border-amber-200 dark:bg-amber-950/30 dark:border-amber-800'
                      }`}
                    >
                      <Calendar className={`h-4 w-4 shrink-0 ${isToday ? 'text-red-500' : 'text-amber-500'}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground truncate">{bill.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {bill.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </p>
                      </div>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full whitespace-nowrap ${
                        isToday
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300'
                      }`}>
                        {isToday ? 'Vence hoje!' : 'Vence amanhã'}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Footer */}
              <div className="px-4 pb-4">
                <Button className="w-full" onClick={() => setOpen(false)}>
                  Entendido
                </Button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}