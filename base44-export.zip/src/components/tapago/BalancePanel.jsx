import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2, Wallet, ChevronDown, ChevronUp } from 'lucide-react';

export default function BalancePanel({ entries, totalIncome, totalPaid, onAdd, onDelete }) {
  const [label, setLabel] = useState('');
  const [amount, setAmount] = useState('');
  const [showForm, setShowForm] = useState(false);

  const available = totalIncome - totalPaid;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!label.trim() || !amount) return;
    onAdd({ label: label.trim(), amount: parseFloat(amount) });
    setLabel('');
    setAmount('');
  };

  const formatCurrency = (val) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border overflow-hidden">
      {/* Saldo disponível — sempre visível */}
      <div className={`flex flex-col sm:flex-row sm:items-center gap-4 p-5 ${available >= 0 ? 'bg-emerald-50 dark:bg-emerald-950/20' : 'bg-red-50 dark:bg-red-950/20'}`}>
        <div className="flex items-center gap-4 flex-1">
          <div className={`h-11 w-11 rounded-xl flex items-center justify-center shrink-0 ${available >= 0 ? 'bg-emerald-100 dark:bg-emerald-900/50' : 'bg-red-100 dark:bg-red-900/50'}`}>
            <Wallet className={`h-5 w-5 ${available >= 0 ? 'text-emerald-600' : 'text-red-600'}`} />
          </div>
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Saldo Disponível</p>
            <p className={`text-2xl font-extrabold ${available >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(available)}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Entradas: {formatCurrency(totalIncome)} · Pago: {formatCurrency(totalPaid)}
            </p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(f => !f)}
          className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors self-start sm:self-center"
        >
          {showForm ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          Adicionar Entrada
        </button>
      </div>

      {/* Formulário expansível */}
      {showForm && (
        <div className="p-5 border-t border-border space-y-4">
          <form onSubmit={handleSubmit} className="flex flex-wrap gap-3 items-end">
            <div className="flex-1 min-w-[160px]">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Descrição</Label>
              <Input
                placeholder="Ex: Salário, Freelance..."
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                className="mt-1"
              />
            </div>
            <div className="w-36">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Valor (R$)</Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="mt-1"
              />
            </div>
            <Button type="submit" className="font-semibold shrink-0">
              <Plus className="h-4 w-4 mr-1" />
              Adicionar
            </Button>
          </form>

          {entries.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {entries.map((entry) => (
                <div key={entry.id} className="flex items-center gap-2 bg-muted/60 rounded-lg px-3 py-1.5">
                  <span className="text-sm font-medium text-foreground">{entry.label}</span>
                  <span className="text-xs text-emerald-600 font-semibold">{formatCurrency(entry.amount)}</span>
                  <button onClick={() => onDelete(entry.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}