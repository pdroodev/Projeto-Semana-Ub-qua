import React from 'react';
import { CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

function SummaryCard({ icon: Icon, label, value, colorClass }) {
  return (
    <div className="flex items-center gap-3 bg-card rounded-xl border border-border p-4 shadow-sm">
      <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${colorClass}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground font-medium truncate">{label}</p>
        <p className="text-base font-bold text-foreground">{value}</p>
      </div>
    </div>
  );
}

export default function Summary({ summary }) {
  const formatCurrency = (val) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="space-y-3">
      <h2 className="text-base font-bold text-foreground">Resumo</h2>
      <div className="grid grid-cols-1 gap-3">
        <SummaryCard
          icon={Clock}
          label="Total pendente"
          value={formatCurrency(summary.totalPending)}
          colorClass="bg-amber-100 text-amber-600"
        />
        <SummaryCard
          icon={CheckCircle2}
          label="Total pago"
          value={formatCurrency(summary.totalPaid)}
          colorClass="bg-emerald-100 text-emerald-600"
        />
        <SummaryCard
          icon={AlertTriangle}
          label="Contas atrasadas"
          value={summary.overdueCount}
          colorClass="bg-red-100 text-red-600"
        />
      </div>
    </div>
  );
}