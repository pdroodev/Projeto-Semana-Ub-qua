import React from 'react';
import Header from '@/components/tapago/Header';
import BillForm from '@/components/tapago/BillForm';
import Summary from '@/components/tapago/Summary';
import BillList from '@/components/tapago/BillList';
import ChartsPanel from '@/components/tapago/ChartsPanel';
import Footer from '@/components/tapago/Footer';
import UrgentAlert from '@/components/tapago/UrgentAlert';
import BalancePanel from '@/components/tapago/BalancePanel';
import useBills from '@/lib/useBills';
import useBalance from '@/lib/useBalance';

export default function Home() {
  const { bills, addBill, togglePaid, deleteBill, summary } = useBills();
  const { entries, totalIncome, addEntry, deleteEntry } = useBalance();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <UrgentAlert bills={bills} />
      <Header />

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Saldo disponível sempre no topo */}
        <BalancePanel
          entries={entries}
          totalIncome={totalIncome}
          totalPaid={summary.totalPaid}
          onAdd={addEntry}
          onDelete={deleteEntry}
        />

        {/* Contas */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 space-y-6">
            <BillForm onAdd={addBill} />
            <Summary summary={summary} />
          </div>
          <div className="lg:col-span-8 space-y-6">
            <BillList bills={bills} onTogglePaid={togglePaid} onDelete={deleteBill} />
            <ChartsPanel bills={bills} />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}